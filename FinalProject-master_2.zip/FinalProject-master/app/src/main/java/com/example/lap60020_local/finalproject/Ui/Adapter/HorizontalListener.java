package com.example.lap60020_local.finalproject.Ui.Adapter;

public interface HorizontalListener {
    void onScroll(int position);
}
