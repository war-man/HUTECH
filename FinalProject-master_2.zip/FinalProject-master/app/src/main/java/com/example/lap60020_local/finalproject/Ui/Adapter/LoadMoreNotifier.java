package com.example.lap60020_local.finalproject.Ui.Adapter;

public interface LoadMoreNotifier {

    void onScroll(int lastseen);

    void loadMore();
}
