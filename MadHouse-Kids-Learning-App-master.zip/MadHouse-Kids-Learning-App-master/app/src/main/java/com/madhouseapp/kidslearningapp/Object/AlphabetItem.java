package com.madhouseapp.kidslearningapp.Object;

/**
 * Created by Akshansh on 05-10-2017.
 */

public class AlphabetItem {

    private String alphabet;

    private AlphabetItem() {
    }

    public AlphabetItem(String alphabet) {
        this.alphabet = alphabet;
    }

    public String getAlphabet() {
        return alphabet;
    }
}
