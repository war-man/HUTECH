# Until_When
An Android application designed to help manage shifts.
[Demo video of the project](https://youtu.be/u5Sw3YTciko). **The project is extremely old and not updated, So it probably won't run today!**
## Getting Started

### Prerequisites


In order to run the project you need:
1. Android Studio

### Installing

1. Download and Install Android Studio from [here](https://developer.android.com/studio).
