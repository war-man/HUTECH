package com.project.gaurs.tadqa.Pojo;

/**
 * Created by gaurs on 6/13/2017.
 */

public class DataFromFirebase {
    String id, name, num, email;

    public DataFromFirebase() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
