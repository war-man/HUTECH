package com.project.gaurs.tadqa.Pojo;

/**
 * Created by gaurs on 5/29/2017.
 */

public class Child {
    String answer;

    public Child(String answer) {
        this.answer = answer;
    }

    public Child() {

    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
