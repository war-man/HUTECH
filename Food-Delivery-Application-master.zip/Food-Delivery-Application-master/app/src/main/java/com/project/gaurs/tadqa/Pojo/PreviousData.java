package com.project.gaurs.tadqa.Pojo;

/**
 * Created by gaurs on 6/16/2017.
 */

public class PreviousData {
    String name, price, url;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
