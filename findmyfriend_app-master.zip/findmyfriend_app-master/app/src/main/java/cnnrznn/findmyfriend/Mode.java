package cnnrznn.findmyfriend;

/**
 * Created by cnnrznn on 10/23/2015.
 */
public enum Mode {
    MAIN, CONNECT, FIND
}
