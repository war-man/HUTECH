package com.example.vedantiladda.ecommerce.LogoutAndEditProfile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.vedantiladda.ecommerce.BaseActivity;
import com.example.vedantiladda.ecommerce.R;

public class HistoryActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history_layout);




    }
}
