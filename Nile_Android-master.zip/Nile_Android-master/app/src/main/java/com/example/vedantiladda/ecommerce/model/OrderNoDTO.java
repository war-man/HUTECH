package com.example.vedantiladda.ecommerce.model;

public class OrderNoDTO {
    private String orderNo;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
