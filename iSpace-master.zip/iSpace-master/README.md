<h1> Android Mobile Application Game </h1>
 
 <b>:star:	:rocket: iSpace :rocket: :star: <br>
:copyright: Alexey Shpigelman & Sapir Abuksis & Yoav Keren </b> :copyright:	<br>

Developing a game in an Android environment using OOP in JAVA. <br>
The game was developed, designed and implemented using SQLite, Multithreading, Animations, Adapters, Intents, Services. <br> <br>
<b> Here you can find a summary of our project: </b> <br>
https://youtu.be/zrCScYq1JCA<br>

<h1>What is the purpose of the game?</h1>
Swipe your finger to guide a spaceship in the galaxy to avoid asteroids and collect coins.<br>
Try to collect as many coins as possible. Get additional bombs and challenge your friends with your best high score!<br>

<h1>What can we do in this app? </h1>
:rocket:	Play 3 kinds of game! (FreeStyle, Faster and Getting Sick)  <br>
:memo:	Dialogs instructions in the entire game! <br>
:floppy_disk:	Save your score to table High Score! <br>
:trophy:	Challenge your friend to get the best high scores and send them your score via Whatsapp!  <br>
:unlock: Buy new spaces from the Space Shop! (by collecting coins) <br>
:speaker: listen to background music and sounds of the game controled by Settings <br>
:heavy_plus_sign: Using PhotoShop, Animation, Confetti, Glide and FancyRoast in extra. <br><br>

<h1>Screenshots</h1><br>
