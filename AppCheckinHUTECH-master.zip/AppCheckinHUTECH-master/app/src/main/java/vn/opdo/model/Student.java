package vn.opdo.model;

public class Student {
    public int IdStudent;
    public String StudentName;
    public String FullNameCheckin;
    public String StudentCode;
    public String StudentClass;
    public String Checkin;
    public int Status;
}
