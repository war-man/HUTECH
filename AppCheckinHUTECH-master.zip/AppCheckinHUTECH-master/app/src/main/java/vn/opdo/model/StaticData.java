package vn.opdo.model;

public class StaticData {
    public static int IdUser;
}
