package vn.opdo.model;

public class Login {
    public String Username;
    public String Password;
}
