package vn.opdo.model;

public class Event {
    public int IdEvent;
    public String EventName;
    public String EventRoom;
    public String EventDate;
}
