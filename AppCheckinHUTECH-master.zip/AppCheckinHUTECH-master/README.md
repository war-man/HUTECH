# App Checkin HUTECH
Là một app android hỗ trợ checkin sự kiện ở HUTECH bằng cách scan qr code hoặc barcode
App rất lúa vì chỉ làm để đem đi demo là chính :v gửi các bạn quan tâm tham khảo

# Hình ảnh
![Màn hình đăng nhập](https://raw.githubusercontent.com/opdo/AppCheckinHUTECH/master/1.png)
![Màn hình chọn sự kiện](https://raw.githubusercontent.com/opdo/AppCheckinHUTECH/master/2.png)
![Màn hình checkin](https://raw.githubusercontent.com/opdo/AppCheckinHUTECH/master/3.png)
