package nhom4.dack.albumanh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AlbumPhotos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_photos);
    }
}
