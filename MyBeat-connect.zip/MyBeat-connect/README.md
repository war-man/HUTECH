MyBeat
======
_Artwork by [Jorge Chato](https://github.com/orggue)_

Android app, MyBeat diabetes is designed to manage blood insulin levels. App designed for diabetics.

<img src="https://raw.githubusercontent.com/orggue/MyBeat/connect/01.png" height="400px"/>
<img src="https://raw.githubusercontent.com/orggue/MyBeat/connect/02.png" height="400px"/>
<img src="https://raw.githubusercontent.com/orggue/MyBeat/connect/03.png" height="400px"/>
<img src="https://raw.githubusercontent.com/orggue/MyBeat/connect/04.png" height="400px"/>
<img src="https://raw.githubusercontent.com/orggue/MyBeat/connect/05.png" height="400px"/>
<img src="https://raw.githubusercontent.com/orggue/MyBeat/connect/06.png" height="400px"/>

## Clone and run project

-Compatible with api 15 (Android 4.0.3 or higher is required) android 15-16-17 still have problems with blur effect

### APK:

-Beta apk available in [MyBeat_diabetes_b.4.1.15](https://betas.to/rr68PxzR)
