package org.jorgechato.mybeat.util;

/**
 * Created by jorge on 12/12/14.
 */
public enum Units {
    MGDL, MMOL
}
