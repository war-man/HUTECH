package com.example.vutran.finderawsome.Direction;

/**
 * Created by VuTran on 6/14/2017.
 */

public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
