package com.example.vutran.finderawsome.Direction;

/**
 * Created by VuTran on 6/14/2017.
 */

public class Distance {
    public String text;
    public int value;

    public Distance(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
