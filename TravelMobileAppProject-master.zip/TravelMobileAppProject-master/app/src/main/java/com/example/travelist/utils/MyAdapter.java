package com.example.travelist.utils;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.travelist.R;
import com.example.travelist.model.Tour;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolderView> {

    private static final int ITEM = 0;
    private static final int LOADING = 1;

    final private MyAdapterOnItemClickListener mListener;

    private List<Tour> mTours;
    private Fragment fragment;
    private boolean isLoadingAdded = false;

    public MyAdapter(MyAdapterOnItemClickListener mListener,Fragment fragment) {
        this.mTours = new ArrayList<>();
        this.mListener = mListener;
        this.fragment = fragment;
    }

    public interface MyAdapterOnItemClickListener{
        void onItemClick(int position);
    }

    public List<Tour> getTours() {
        return mTours;
    }

    public void setTours(List<Tour> mTours) {
        this.mTours = mTours;
    }

    @NonNull
    @Override
    public MyHolderView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = null;

        switch (viewType) {
            case ITEM:
                view = inflater.inflate(R.layout.item, parent, false);
                break;
            case LOADING:
                view = inflater.inflate(R.layout.item_progress,parent,false);
                break;
        }

        MyHolderView vh = new MyHolderView(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolderView holder, int position) {

        switch (getItemViewType(position)) {
            case ITEM:
                TextView tvLocation = holder.tvLocation;
                TextView tvCalendar = holder.tvCalendar;
                TextView tvPeople = holder.tvPeople;
                TextView tvMoney = holder.tvMoney;
                ImageView imVTour = holder.imVTour;

                Tour tour = mTours.get(position);
                Glide.with(fragment)
                        .load(tour.getAvatar())
                        .into(imVTour);
                tvLocation.setText(tour.getName());
                String dateDisplay = ValidUtils.getDate(Long.parseLong(tour.getStartDate())) + " - " +
                        ValidUtils.getDate(Long.parseLong(tour.getEndDate()));
                tvCalendar.setText(dateDisplay);
                tvPeople.setText(String.valueOf(tour.getPeople()));
                String costDisplay = tour.getMinCost() + " - " + tour.getMaxCost();
                tvMoney.setText(costDisplay);
                break;
            case LOADING:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return mTours == null ? 0 : mTours.size();
    }

    @Override
    public int getItemViewType(int position) {
        return (position == mTours.size() - 1 && isLoadingAdded) ? LOADING : ITEM;
    }


    //helper

    public void add(Tour tour){
        mTours.add(tour);
        notifyItemInserted(mTours.size() - 1);
    }

    public void addAll(List<Tour> tours){
        for (Tour tour : tours) {
            add(tour);
        }
    }

    public void remove(Tour tour){
        int position = mTours.indexOf(tour);
        if (position > -1){
            mTours.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void clear(){
        isLoadingAdded = false;
        while (getItemCount() > 0){
            remove(getItem(0));
        }
    }

    public boolean isEmpty(){
        return getItemCount() == 0;
    }

    public void addLoadingFooter(){
        isLoadingAdded = true;
        add(new Tour());
    }

    public void removeLoadingFooter(){
        isLoadingAdded = false;

        int position = mTours.size() - 1;
        Tour tour = getItem(position);

        if (tour != null){
            mTours.remove(position);
            notifyItemRemoved(position);
        }
    }

    public Tour getItem(int position){
        return mTours.get(position);
    }

    //HolderView

    public class MyHolderView extends RecyclerView.ViewHolder{

        public ImageView imVTour;
        public TextView tvLocation;
        public TextView tvCalendar;
        public TextView tvPeople;
        public TextView tvMoney;

        public MyHolderView(@NonNull View itemView) {
            super(itemView);


            imVTour = (ImageView) itemView.findViewById(R.id.imgv_tour);
            tvLocation = (TextView) itemView.findViewById(R.id.tv_location);
            tvCalendar = (TextView) itemView.findViewById(R.id.tv_calendar);
            tvPeople = (TextView) itemView.findViewById(R.id.tv_people);
            tvMoney = (TextView) itemView.findViewById(R.id.tv_money);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    mListener.onItemClick(position);
                }
            });
        }
    }

    public class MyFooterView extends RecyclerView.ViewHolder{

        public MyFooterView(@NonNull View itemView) {
            super(itemView);
        }
    }
}
