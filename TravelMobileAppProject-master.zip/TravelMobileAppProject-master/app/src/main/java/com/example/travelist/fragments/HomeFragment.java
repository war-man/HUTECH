package com.example.travelist.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.Group;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.travelist.R;
import com.example.travelist.model.Tour;
import com.example.travelist.model.TourListResponse;
import com.example.travelist.network.MyAPIClient;
import com.example.travelist.network.UserService;
import com.example.travelist.utils.MyAdapter;
import com.example.travelist.view.CreateTourActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements MyAdapter.MyAdapterOnItemClickListener {

    private static final String TAG = HomeFragment.class.getSimpleName();

    //UI components
    private ProgressBar mLoadingIndicator;
    private TextView mNone;
    private FloatingActionButton mFab;
    private Group mErrorGroup;
    private MaterialButton mRetry;
    private RecyclerView rvTour;

    private MyAdapter mAdapter;
    private UserService mUserService;
    private LinearLayoutManager layoutManager;

    private boolean isLoading = false;
    private boolean isLastPage = false;
    private  final int PAGE_SIZE = 10;
    private int currentPage = 1;
    private int totals = 0;
    private int currentSize = 0;


    private RecyclerView.OnScrollListener recyclerViewOnScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);

            if (dy > 0 && mFab.getVisibility() == View.VISIBLE) {
                mFab.hide();
            } else if (dy < 0 && mFab.getVisibility() != View.VISIBLE) {
                mFab.show();
            }

            int visibleItemCount = layoutManager.getChildCount();
            int totalItemCount = layoutManager.getItemCount();
            int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();

            if (!isLoading && !isLastPage) {
                if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount
                        && firstVisibleItemPosition >= 0
                        && totalItemCount >= PAGE_SIZE) {
                    loadMoreItems();
                }
            }
        }
    };

    private void loadMoreItems() {
        isLoading = true;
        currentPage++;
        Call<TourListResponse> call = mUserService.getUserTourList("10",String.valueOf(currentPage));
        call.enqueue(nextFetchCallback);
    }

    private Callback<TourListResponse> firstFetchCallback = new Callback<TourListResponse>() {
        @Override
        public void onResponse(Call<TourListResponse> call, Response<TourListResponse> response) {
            isLoading = false;
            mLoadingIndicator.setVisibility(View.GONE);
            mNone.setVisibility(View.GONE);
            if (!response.isSuccessful()){
                mErrorGroup.setVisibility(View.VISIBLE);
                return;
            }
            if (response.body() != null) {
                totals = response.body().getTotal();
                List<Tour> tours = fetchTours(response);
                if (tours != null) {
                    if (tours.size() > 0) {
                        currentSize += tours.size();
                        for (Tour tour : tours){
                            tour.setDefaultAvatar();
                        }
                        mAdapter.addAll(tours);
                    }
                    else{
                        mNone.setVisibility(View.VISIBLE);
                        return;
                    }
                    if (tours.size() >= PAGE_SIZE || currentSize < totals){
                        mAdapter.addLoadingFooter();
                    }
                    else{
                        isLastPage = true;
                    }
                }
            }
        }

        @Override
        public void onFailure(Call<TourListResponse> call, Throwable t) {
            mLoadingIndicator.setVisibility(View.GONE);
            mErrorGroup.setVisibility(View.VISIBLE);
        }
    };

    private Callback<TourListResponse> nextFetchCallback = new Callback<TourListResponse>() {
        @Override
        public void onResponse(Call<TourListResponse> call, Response<TourListResponse> response) {
            mAdapter.removeLoadingFooter();
            isLoading = false;
            if (!response.isSuccessful()){
                isLastPage = true;
                return;
            }
            if (response.body() != null){
                List<Tour> tours = fetchTours(response);
                Log.d(TAG, String.format("%s",tours));
                if (tours != null) {
                    if (tours.size() > 0) {
                        currentSize += tours.size();
                        for (Tour tour : tours) {
                            tour.setDefaultAvatar();
                        }
                        Log.d(TAG, String.format("%d",tours.size()));
                        mAdapter.addAll(tours);
                    }
                    if (tours.size() >= PAGE_SIZE || currentSize < totals){
                        mAdapter.addLoadingFooter();
                    }
                    else{
                        isLastPage = true;
                    }
                }
            }
        }

        @Override
        public void onFailure(Call<TourListResponse> call, Throwable t) {
            mAdapter.removeLoadingFooter();
        }
    };

    private List<Tour> fetchTours(Response<TourListResponse> response){
        return response.body().getTours();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mUserService = MyAPIClient.getInstance().getAdapter().create(UserService.class);
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        mLoadingIndicator = root.findViewById(R.id.pb_home);
        mFab = root.findViewById(R.id.fab);
        mErrorGroup = root.findViewById(R.id.error_group);
        rvTour = root.findViewById(R.id.rv_tour);
        mRetry = root.findViewById(R.id.btn_error);
        mNone = root.findViewById(R.id.tv_none);
        mRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mErrorGroup.setVisibility(View.GONE);
                mLoadingIndicator.setVisibility(View.VISIBLE);
                Call<TourListResponse> call = mUserService.getUserTourList("10","1");
                call.enqueue(firstFetchCallback);
            }
        });
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setRecyclerView();
        Call<TourListResponse> call = mUserService.getUserTourList("10","1");
        call.enqueue(firstFetchCallback);
        mFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createTour();
            }
        });
    }

    private void createTour() {
        Intent intent = new Intent(this.getContext(), CreateTourActivity.class);
        startActivity(intent);
    }


    @Override
    public void onItemClick(int position) {

    }

    private void setRecyclerView(){
        mAdapter = new MyAdapter(this,this);
        rvTour.setAdapter(mAdapter);
        layoutManager = new LinearLayoutManager(getActivity());
        rvTour.setLayoutManager(layoutManager);
        rvTour.setItemViewCacheSize(20);
        rvTour.setItemAnimator(new DefaultItemAnimator());
        rvTour.addOnScrollListener(recyclerViewOnScrollListener);
    }

}