package com.example.travelist.view;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.travelist.R;
import com.example.travelist.network.MyAPIClient;
import com.example.travelist.network.UserService;
import com.example.travelist.utils.ValidUtils;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswordActivity extends AppCompatActivity {
    private static String TAG = ForgotPasswordActivity.class.getSimpleName();

    private EditText mInfo;
    private MaterialButton mSubmit;
    private UserService mUserService;
    private Toast mToast;
    private AlertDialog mAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        mInfo = (EditText)findViewById(R.id.edt_submit);
        mSubmit = (MaterialButton) findViewById(R.id.submit_btn);
        mUserService = MyAPIClient.getInstance().getAdapter().create(UserService.class);

        AlertDialog.Builder builder = new AlertDialog.Builder(ForgotPasswordActivity.this);
        builder.setCancelable(false);
        builder.setView(R.layout.layout_loading_dialog);
        mAlertDialog = builder.create();

        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mInfo.setError(null);
                String info = mInfo.getText().toString();
                String type = "";
                boolean cancel = false;
                View focusView = null;
                if (ValidUtils.validPhone(info)){
                    type = "phone";
                }
                else if (ValidUtils.validEmail(info)){
                    type = "email";
                }
                else{
                    cancel = true;
                }
                if (cancel){
                    mInfo.setError("Invalid information");
                    focusView = mInfo;
                    focusView.requestFocus();
                }
                else{
                    mAlertDialog.show();
                    Call<Void> call = mUserService.requestRecoveryPassword(type,info);
                    call.enqueue(new Callback<Void>() {
                        @Override
                        public void onResponse(Call<Void> call, Response<Void> response) {
                            if (!response.isSuccessful()){
                                mAlertDialog.dismiss();
                                if (response.code() == 404) {
                                    toastMakeText("EMAIL/PHONE doesn't exist");
                                }
                                else {
                                    toastMakeText(response.message());
                                }
                            }
                            else{
                                Intent intent = new Intent(ForgotPasswordActivity.this,LoginActivity.class);
                                mAlertDialog.dismiss();
                                startActivity(intent);
                                finish();
                            }
                        }

                        @Override
                        public void onFailure(Call<Void> call, Throwable t) {
                            mAlertDialog.dismiss();
                            Log.d(TAG, String.format("%s",t.getMessage()));
                        }
                    });
                }
            }
        });
    }

    private void toastMakeText(String text) {
        if (mToast != null) mToast.cancel();
        mToast = Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT);
        mToast.show();
    }
}
