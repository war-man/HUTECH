package com.example.travelist.view;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.travelist.R;
import com.example.travelist.model.ExtraLoginRequest;
import com.example.travelist.model.GoogleAuthResponse;
import com.example.travelist.model.LoginRequest;
import com.example.travelist.model.LoginResponse;
import com.example.travelist.network.GoogleService;
import com.example.travelist.network.MyAPIClient;
import com.example.travelist.network.UserService;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.example.travelist.utils.ValidUtils.validInfo;
import static com.example.travelist.utils.ValidUtils.validPassword;

public class LoginActivity extends AppCompatActivity {

    private int RC_SIGN_IN = 9001;
    private static final String TAG = LoginActivity.class.getSimpleName();

    private TextInputEditText mInfo;
    private TextInputEditText mPassword;
    private TextInputLayout mInfoLayout;
    private TextInputLayout mPasswordLayout;
    private TextView mSignUp;
    private TextView mForgotPassword;
    private MaterialButton mSignInButton;
    private ImageButton mFacebookSignIn;
    private ImageButton mGoogleSignIn;
    private UserService mUserService;
    private Toast mToast;
    private AlertDialog mAlertDialog;
    private CallbackManager mCallbackManager;
    private SharedPreferences mPreferences;
    private GoogleSignInClient mGoogleSignInClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mUserService = MyAPIClient.getInstance().getAdapter().create(UserService.class);
        mPreferences = getSharedPreferences(getString(R.string.pref_key), MODE_PRIVATE);

        //facebook callback manager
        mCallbackManager = CallbackManager.Factory.create();

        //google sign in
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.server_client_id))
                .requestServerAuthCode(getString(R.string.server_client_id))
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        //get UI components
        mInfo = (TextInputEditText) findViewById(R.id.edt_info);
        mPassword = (TextInputEditText) findViewById(R.id.edt_password);
        mInfoLayout = (TextInputLayout) findViewById(R.id.til_username);
        mPasswordLayout = (TextInputLayout) findViewById(R.id.til_password);
        mSignInButton = (MaterialButton) findViewById(R.id.btn_sign_up);
        mFacebookSignIn = (ImageButton) findViewById(R.id.facebook_btn);
        mGoogleSignIn = (ImageButton) findViewById(R.id.google_btn);
        mSignUp = (TextView) findViewById(R.id.tv_sign_up);
        mForgotPassword = (TextView) findViewById(R.id.tv_forgot_password);

        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        builder.setCancelable(false);
        builder.setView(R.layout.layout_loading_dialog);
        mAlertDialog = builder.create();


        mSignInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attempLogin();
            }
        });

        mFacebookSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAlertDialog.show();
                LoginManager.getInstance().logInWithReadPermissions(LoginActivity.this, Arrays.asList("public_profile", "user_friends"));
                LoginManager.getInstance().registerCallback(mCallbackManager, new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        facebookLogin(loginResult.getAccessToken());
                    }

                    @Override
                    public void onCancel() {
                        mAlertDialog.dismiss();
                    }

                    @Override
                    public void onError(FacebookException error) {
                        mAlertDialog.dismiss();
                    }
                });
            }
        });

        mGoogleSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                googleLogin();
            }
        });

        mSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

        mForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,ForgotPasswordActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mCallbackManager.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void attempLogin() {
        ;

        //reset errors
        mInfoLayout.setError(null);
        mPasswordLayout.setError(null);

        //store value
        final String info = mInfo.getText().toString();
        String password = mPassword.getText().toString();

        boolean cancel = false;
        View focusView = null;

        if (!validInfo(info)) {
            mInfoLayout.setError("Enter a valid email or phone number");
            focusView = mInfo;
            cancel = true;
        }

        if (!validPassword(password)) {
            mPasswordLayout.setError("Enter a valid password");
            focusView = mPassword;
            cancel = true;
        }

        if (cancel){
            focusView.requestFocus();
        }
        else{
            mAlertDialog.show();

            final LoginRequest request = new LoginRequest();
            request.setInfo(info);
            request.setPassword(password);
            Call<LoginResponse> call = mUserService.login(request);
            call.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    if (!response.isSuccessful()) {
                        mAlertDialog.dismiss();
                        toastMakeText("Invalid info or password");
                    } else {
                        String accessToken = response.body().getToken();
                        String userId = response.body().getId();

                        MyAPIClient.getInstance().setAccessToken(accessToken);
                        MyAPIClient.getInstance().setUserId(userId);

                        SharedPreferences.Editor editor = mPreferences.edit();
                        editor.putString(getString(R.string.token_key), accessToken);
                        editor.putString(getString(R.string.user_id_key), userId);
                        editor.apply();

                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();

                        mAlertDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                    mAlertDialog.dismiss();
                }
            });
        }
    }

    private void facebookLogin(AccessToken facebookAccessToken) {
        mAlertDialog.show();
        final ExtraLoginRequest request = new ExtraLoginRequest();
        request.setAccessToken(facebookAccessToken.getToken());
        Call<LoginResponse> call = mUserService.facebookLogin(request);
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (!response.isSuccessful()) {
                    mAlertDialog.dismiss();
                    toastMakeText("Login by facebook failed");
                } else {
                    String accessToken = response.body().getToken();
                    String userId = response.body().getId();

                    MyAPIClient.getInstance().setAccessToken(accessToken);
                    MyAPIClient.getInstance().setUserId(userId);

                    SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.pref_key), MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(getString(R.string.token_key), accessToken);
                    editor.putString(getString(R.string.user_id_key), userId);
                    editor.apply();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();

                    mAlertDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                mAlertDialog.dismiss();
            }
        });
    }

    private void googleLogin() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void googleLogin(GoogleSignInAccount account) {
        if (account != null) {
            mAlertDialog.show();
            final String googleToken = account.getIdToken();
            final String googleAuthCode = account.getServerAuthCode();
            Log.d(TAG, String.format("update UI authcode: %s", googleAuthCode));
            getGoogleAccessToken(googleAuthCode, googleToken);
            final ExtraLoginRequest request = new ExtraLoginRequest();
            String googleAccessToken = mPreferences.getString(getString(R.string.google_token_key), null);
            Log.d(TAG, String.format("googleAcessToken: %s", googleAccessToken));
            request.setAccessToken(googleAccessToken);
            Call<LoginResponse> call = mUserService.googleLogin(request);
            call.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    if (!response.isSuccessful()) {
                        mAlertDialog.dismiss();
                        Log.d(TAG, String.format("googleID: %s", googleToken));
                        toastMakeText("Login by google failed");
                    } else {
                        String accessToken = response.body().getToken();
                        String userId = response.body().getId();

                        MyAPIClient.getInstance().setAccessToken(accessToken);

                        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.pref_key), MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString(getString(R.string.token_key), accessToken);
                        editor.putString(getString(R.string.user_id_key), userId);
                        editor.apply();

                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();

                        mAlertDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                    mAlertDialog.dismiss();
                }
            });
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            // Signed in successfully, show authenticated UI.
            googleLogin(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
        }
    }

    private void getGoogleAccessToken(String authCode, String idToken) {
        OkHttpClient client = new OkHttpClient();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://oauth2.googleapis.com")
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        Call<GoogleAuthResponse> call = retrofit.create(GoogleService.class).getToken(
                "authorization_code", getString(R.string.server_client_id),
                getString(R.string.client_secret), "", idToken, authCode
        );
        call.enqueue(new Callback<GoogleAuthResponse>() {
            @Override
            public void onResponse(Call<GoogleAuthResponse> call, Response<GoogleAuthResponse> response) {
                if (!response.isSuccessful()) {

                } else {
                    String googleAccessToken = response.body().getAccessToken();
                    Log.d(TAG, String.format("GoogleAuthResponse: %s", googleAccessToken));
                    SharedPreferences.Editor editor = mPreferences.edit();
                    editor.putString(getString(R.string.google_token_key), googleAccessToken);
                    editor.apply();
                }
            }

            @Override
            public void onFailure(Call<GoogleAuthResponse> call, Throwable t) {
                Log.d(TAG, String.format("%s", t.getMessage()));
            }
        });
    }

    private void toastMakeText(String text) {
        if (mToast != null) mToast.cancel();
        mToast = Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT);
        mToast.show();
    }

}
