package com.example.travelist.network;

import com.example.travelist.model.ExtraLoginRequest;
import com.example.travelist.model.LoginRequest;
import com.example.travelist.model.LoginResponse;
import com.example.travelist.model.RegisterRequest;
import com.example.travelist.model.RegisterResponse;
import com.example.travelist.model.TourListResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface UserService {
    @POST("/user/login")
    Call<LoginResponse> login(@Body LoginRequest request);
    @POST("user/login/by-facebook")
    Call<LoginResponse> facebookLogin(@Body ExtraLoginRequest request);
    @POST("user/login/by-google")
    Call<LoginResponse> googleLogin(@Body ExtraLoginRequest request);
    @POST("user/register")
    Call<RegisterResponse> register(@Body RegisterRequest request);
    @GET("tour/list")
    Call<TourListResponse> getAvailableTourList(@Query("rowPerPage") String rowPerPage, @Query("pageNum") String pageNum);
    @GET("tour/history-user")
    Call<TourListResponse> getUserTourList(@Query("pageIndex") String pageIndex, @Query("pageSize") String pageSize);
    @FormUrlEncoded
    @POST("/user/request-otp-recovery")
    Call<Void> requestRecoveryPassword(@Field("type") String type, @Field("value") String value);
}
