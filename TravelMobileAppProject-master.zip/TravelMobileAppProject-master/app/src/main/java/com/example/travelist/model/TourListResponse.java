package com.example.travelist.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TourListResponse {
    @SerializedName("total")
    private int total;
    @SerializedName("tours")
    private List<Tour> tours;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<Tour> getTours() {
        return tours;
    }

    public void setTours(List<Tour> tours) {
        this.tours = tours;
    }
}