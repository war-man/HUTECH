package com.example.travelist.view;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.travelist.R;
import com.example.travelist.model.RegisterRequest;
import com.example.travelist.model.RegisterResponse;
import com.example.travelist.network.MyAPIClient;
import com.example.travelist.network.UserService;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.travelist.utils.ValidUtils.validEmail;
import static com.example.travelist.utils.ValidUtils.validPhone;

public class SignupActivity extends AppCompatActivity {
    private final static String TAG=SignupActivity.class.getSimpleName();

    private TextInputLayout mEmailLayout;
    private TextInputLayout mPhoneLayout;
    private TextInputLayout mPasswordLayout;
    private TextInputLayout mConfirmLayout;
    private TextInputEditText mEmail;
    private TextInputEditText mPhone;
    private TextInputEditText mPassword;
    private TextInputEditText mConfirmPassword;
    private MaterialButton mSignUp;
    private AlertDialog mAlertDialog;
    private UserService mUserService;
    private Toast mToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        assert (getSupportActionBar() != null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mUserService = MyAPIClient.getInstance().getAdapter().create(UserService.class);

        //get ui components
        mEmailLayout = (TextInputLayout) findViewById(R.id.til_email);
        mConfirmLayout = (TextInputLayout) findViewById(R.id.til_confirm_password);
        mPasswordLayout = (TextInputLayout) findViewById(R.id.til_password);
        mPhoneLayout = (TextInputLayout) findViewById(R.id.til_phone);
        mEmail = (TextInputEditText)findViewById(R.id.edt_email);
        mPhone = (TextInputEditText)findViewById(R.id.edt_phone);
        mPassword = (TextInputEditText)findViewById(R.id.edt_password);
        mConfirmPassword = (TextInputEditText)findViewById(R.id.edt_confirm_password);
        mSignUp = (MaterialButton) findViewById(R.id.btn_sign_up);

        AlertDialog.Builder builder = new AlertDialog.Builder(SignupActivity.this);
        builder.setCancelable(false);
        builder.setView(R.layout.layout_loading_dialog);
        mAlertDialog = builder.create();

        mSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUp();
            }
        });
    }

    private void signUp(){
        //reset errors
        mEmailLayout.setError(null);
        mPhoneLayout.setError(null);
        mPasswordLayout.setError(null);
        mConfirmLayout.setError(null);

        String email = mEmail.getText().toString();
        String phone = mPhone.getText().toString();
        String password = mPassword.getText().toString();
        String confirmPassword = mConfirmPassword.getText().toString();

        boolean cancel = false;
        View focusView = null;

        if (!validEmail(email)){
            mEmailLayout.setError("Invalid email");
            focusView = mEmail;
            cancel = true;
        }

        if (!validPhone(phone)){
            mPhoneLayout.setError("Invalid phone");
            focusView = mPhone;
            cancel = true;
        }

        if (TextUtils.isEmpty(password)){
            mPasswordLayout.setError("Invalid password");
            focusView = mPassword;
            cancel = true;
        }

        if (TextUtils.isEmpty(confirmPassword)){
            mConfirmLayout.setError("Invalid");
            focusView = mConfirmPassword;
            cancel = true;
        }

        if (!password.equals(confirmPassword)){
            mConfirmLayout.setError(null);
            mConfirmLayout.setError("Confirm password is not right");
            focusView = mConfirmPassword;
            cancel = true;
        }

        if (cancel){
            focusView.requestFocus();
        }
        else{
            mAlertDialog.show();
            RegisterRequest request = new RegisterRequest();
            request.setEmail(email);
            request.setPhone(phone);
            request.setPassword(password);
            Call<RegisterResponse> call = mUserService.register(request);
            call.enqueue(new Callback<RegisterResponse>() {
                @Override
                public void onResponse(Call<RegisterResponse> call, Response<RegisterResponse> response) {
                    if (!response.isSuccessful()){
                        mAlertDialog.dismiss();
                        if (response.code() == 400){
                            toastMakeText("Email or phone has been registered");
                        }
                        else{
                            toastMakeText(response.message());
                        }
                    }
                    else{
                        Intent intent = new Intent(SignupActivity.this,LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                        mAlertDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<RegisterResponse> call, Throwable t) {
                    toastMakeText(t.getMessage());
                    mAlertDialog.dismiss();
                }
            });
        }
    }

    private void toastMakeText(String text) {
        if (mToast != null) mToast.cancel();
        mToast = Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT);
        mToast.show();
    }
}

