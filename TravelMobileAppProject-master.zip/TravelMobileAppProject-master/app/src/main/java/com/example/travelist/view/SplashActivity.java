package com.example.travelist.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;

import com.example.travelist.R;
import com.example.travelist.network.MyAPIClient;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.pref_key),MODE_PRIVATE);
        String accessToken = sharedPreferences.getString(getString(R.string.token_key),null);
        String userId = sharedPreferences.getString(getString(R.string.user_id_key),null);

        MyAPIClient.getInstance().setAccessToken(accessToken);
        MyAPIClient.getInstance().setUserId(userId);

        if (TextUtils.isEmpty(accessToken)){
            Intent intent = new Intent(SplashActivity.this,LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
        else{
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
    }
}
