package com.example.travelist.model;

import com.google.gson.annotations.SerializedName;

public class LoginRequest {
    @SerializedName("emailPhone")
    private String info;
    @SerializedName("password")
    private String password;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
