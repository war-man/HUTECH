package com.example.travelist.utils;

import android.text.TextUtils;
import android.util.Patterns;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.util.regex.Pattern;

public class ValidUtils {
    public static boolean validInfo(String info) {
        return validEmail(info) || validPhone(info);
    }

    public static boolean validPassword(String password) {
        return !TextUtils.isEmpty(password);
    }

    public static boolean validEmail(String email){
        if (TextUtils.isEmpty(email)) {
            return false;
        }
        Pattern emailPattern = Patterns.EMAIL_ADDRESS;
        return emailPattern.matcher(email).matches();
    }

    public static boolean validPhone(String phone){
        if (TextUtils.isEmpty(phone)) {
            return false;
        }
        Pattern mobilePattern = Pattern.compile("(09|01[2|6|8|9])+([0-9]{8})\\b");
        return mobilePattern.matcher(phone).matches();
    }

    public static String getDate(long milliSeconds){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        formatter.setTimeZone(TimeZone.getDefault());
        String dateString = formatter.format(new Date(milliSeconds));
        return dateString;
    }

    private static String getCurrentTimezoneOffset() {
        TimeZone tz = TimeZone.getDefault();
        Calendar cal = GregorianCalendar.getInstance(tz);
        int offsetInMillis = tz.getOffset(cal.getTimeInMillis());

        String offset = String.format("%02d:%02d", Math.abs(offsetInMillis / 3600000), Math.abs((offsetInMillis / 60000) % 60));
        offset = "GMT"+(offsetInMillis >= 0 ? "+" : "-") + offset;

        return offset;
    }
}
