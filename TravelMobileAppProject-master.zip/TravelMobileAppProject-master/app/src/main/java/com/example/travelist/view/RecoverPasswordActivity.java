package com.example.travelist.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.travelist.R;

public class RecoverPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recover_password);
    }
}
