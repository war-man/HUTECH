package com.example.travelist.model;

import com.google.gson.annotations.SerializedName;

public class GoogleAuthResponse {
    @SerializedName("access_token")
    private String accessToken;
    @SerializedName("token-type")
    private String type;
    @SerializedName("expires_in")
    private int expiredTime;
    @SerializedName("id_token")
    private String idToken;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getExpiredTime() {
        return expiredTime;
    }

    public void setExpiredTime(int expiredTime) {
        this.expiredTime = expiredTime;
    }

    public String getIdToken() {
        return idToken;
    }

    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }
}
