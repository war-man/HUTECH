package com.example.travelist.view;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.travelist.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CreateTourActivity extends AppCompatActivity {

    EditText edtTourName;
    EditText edtStartDate;
    EditText edtEndDate;
    EditText edtAdults;
    EditText edtChildren;
    EditText edtMinCost;
    EditText edtMaxCost;
    CheckBox chkPrivate;
    Button btnCreateTour;

    ImageView imgStartDate;
    ImageView imgEndDate;

    Calendar calendar=Calendar.getInstance();
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_tour);
        addControls();
        addEvents();
    }

    private void addEvents() {
        imgStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(v);
            }
        });
        imgEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(v);
            }
        });
    }

    private void showDatePickerDialog(final View v) {
        DatePickerDialog.OnDateSetListener callBack=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                if(v.getId()==R.id.img_date1)
                    edtStartDate.setText(sdf.format(calendar.getTime()));
                else if(v.getId()==R.id.img_date2)
                    edtEndDate.setText(sdf.format(calendar.getTime()));
            }
        };
        DatePickerDialog datePickerDialog=new DatePickerDialog(
                CreateTourActivity.this,
                callBack,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();

    }


    private void addControls() {
        edtAdults=findViewById(R.id.edt_adults);
        edtTourName=findViewById(R.id.edt_tour_name);
        edtStartDate=findViewById(R.id.edt_start_date);
        edtEndDate=findViewById(R.id.edt_end_date);
        edtChildren=findViewById(R.id.edt_children);
        edtMinCost=findViewById(R.id.edt_min_cost);
        edtMaxCost=findViewById(R.id.edt_max_cost);
        chkPrivate=findViewById(R.id.chk_private);

        btnCreateTour=findViewById(R.id.btn_create);

        imgStartDate=findViewById(R.id.img_date1);
        imgEndDate=findViewById(R.id.img_date2);
    }

}
