package com.example.travelist.model;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

public class Tour {
    private int id;
    private int status;
    private String name;
    private String minCost;
    private String maxCost;
    private String startDate;
    private String endDate;
    private int adults;
    private  int childs;
    private boolean isPrivate;
    private String avatar;

    public Tour() {
    }

    public Tour(int id, int status, String name, String minCost, String maxCost, String startDate, String endDate, int adults, int childs, boolean isPrivate, String avatar) {
        this.id = id;
        this.status = status;
        this.name = name;
        this.minCost = minCost;
        this.maxCost = maxCost;
        this.startDate = startDate;
        this.endDate = endDate;
        this.adults = adults;
        this.childs = childs;
        this.isPrivate = isPrivate;
        this.avatar = avatar;
        if (avatar == null || TextUtils.isEmpty(avatar)){
            this.avatar="https://i.imgur.com/GaCp5PI.jpg";
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMinCost() {
        return minCost;
    }

    public void setMinCost(String minCost) {
        this.minCost = minCost;
    }

    public String getMaxCost() {
        return maxCost;
    }

    public void setMaxCost(String maxCost) {
        this.maxCost = maxCost;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getAdults() {
        return adults;
    }

    public void setAdults(int adults) {
        this.adults = adults;
    }

    public int getChilds() {
        return childs;
    }

    public void setChilds(int childs) {
        this.childs = childs;
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public void setPrivate(boolean aPrivate) {
        isPrivate = aPrivate;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
        if (avatar == null || TextUtils.isEmpty(avatar)){
            this.avatar = "https://i.imgur.com/GaCp5PI.jpg";
        }
    }

    public void setDefaultAvatar(){
        if (avatar == null || TextUtils.isEmpty(avatar)){
            avatar = "https://www.qantas.com/content/travelinsider/en/explore/asia/indonesia/bali/what-not-to-do-in-bali/_jcr_content/parsysTop/hero.img.full.medium.jpg/1543366401968.jpg";
        }
    }

    public int getPeople(){
        return getAdults()+getChilds();
    }

}
