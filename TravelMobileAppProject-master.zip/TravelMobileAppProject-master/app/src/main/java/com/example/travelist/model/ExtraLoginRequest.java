package com.example.travelist.model;

import com.facebook.AccessToken;
import com.google.gson.annotations.SerializedName;

public class ExtraLoginRequest {
    @SerializedName("accessToken")
    private String accessToken;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
