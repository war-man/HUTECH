package com.example.user.geton;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.example.user.geton.Interfaces.DriverCommunicator;
import com.example.user.geton.Interfaces.RiderCommunicator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Created by Yi Xuan on 5/2/2018.
 */

public class DriverFragment extends android.app.Fragment {

    // Views
    PlaceAutocompleteFragment locationPickup;
    PlaceAutocompleteFragment locationDestination;
    AutocompleteFilter countryFilter;
    View pickupCancel;
    View destinationCancel;
    String pickupPlace, destinationPlace;
    String pickupURL, destinationURL;
    TextView pickupDate, pickupTime;
    EditText price;

    // Communicator
    DriverCommunicator communicator;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Defines xml for fragment
        return inflater.inflate(R.layout.driver_upload_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // init place value
        pickupPlace = "";
        destinationPlace = "";

        // Init cancel buttons for both input segment
        pickupCancel = view.findViewById(R.id.driver_clear_start);
        destinationCancel = view.findViewById(R.id.driver_clear_destination);

        // Init both PlaceAutocompleteFragment
        locationPickup = (PlaceAutocompleteFragment) getChildFragmentManager().findFragmentById(R.id.driver_start);
        locationDestination = (PlaceAutocompleteFragment) getChildFragmentManager().findFragmentById(R.id.driver_destination);

        // Changing attribute of search file (PlaceAutocompleteFragment)
        (locationPickup.getView().findViewById(R.id.place_autocomplete_search_button)).setVisibility(View.GONE);
        (locationDestination.getView().findViewById(R.id.place_autocomplete_search_button)).setVisibility(View.GONE);
        ((EditText)locationPickup.getView().findViewById(R.id.place_autocomplete_search_input)).setTextSize(17.0f);
        ((EditText)locationDestination.getView().findViewById(R.id.place_autocomplete_search_input)).setTextSize(17.0f);

        // Change hint for both PlaceAutocompleteFragment
        locationPickup.setHint("From...");
        locationDestination.setHint("To...");

        // Set filter for both PlaceAutoCompleteFragment
        countryFilter = new AutocompleteFilter.Builder()
                .setCountry("MY")
                .build();
        locationPickup.setFilter(countryFilter);
        locationDestination.setFilter(countryFilter);

        // init date picker and time picker
        pickupDate = view.findViewById(R.id.driver_datepicker);
        pickupTime = view.findViewById(R.id.driver_timepicker);

        // init price editText
        price = view.findViewById(R.id.driver_price);
        // remove underline in default editText
        price.getBackground().clearColorFilter();

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // Init communicator with activity
        communicator = (DriverCommunicator) getActivity();

        // Set onClickListener for both cancel button
        pickupCancel.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                // Empty the search box
                locationPickup.setText("");
                // Trigger listener in activity
                communicator.driverPickupCanceled();
                return true;
            }
        });
        destinationCancel.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                // Empty the search box
                locationDestination.setText("");
                // Trigger listener in activity
                communicator.driverDestinationCanceled();
                return true;
            }
        });

        // Set onClickListener for both PlaceAutoCompleteFragment
        locationPickup.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // Get place name in url format
                pickupURL = place.getAddress().toString();
                pickupURL = pickupURL.replace(" ","+"); // Replace space with '+' to meet url format
                // Send place URL to activity
                communicator.driverPickupSelected(pickupURL);
            }

            @Override
            public void onError(Status status) {
                // If failed, trigger fail listener in activity
                communicator.driverPlaceSelectedFailed("Error: "+status.getStatusMessage());
            }
        });
        locationDestination.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // Get place name in url format
                destinationURL = place.getAddress().toString();
                destinationURL = destinationURL.replace(" ","+"); // Replace space with '+' to meet url format
                // Send place URL to activity
                communicator.driverDestinationSelected(destinationURL);
            }

            @Override
            public void onError(Status status) {
                // If failed, trigger fail listener in activity
                communicator.driverPlaceSelectedFailed("Error: "+status.getStatusMessage());
            }
        });

        // Set onClickListener for date and time picker
        pickupDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                communicator.driverDateOnClicked();
            }
        });
        pickupTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                communicator.driverTimeOnClicked();
            }
        });

        // Set onClickListener for price editText
        price.addTextChangedListener(new TextWatcher() {
            private String current = "";

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!charSequence.toString().equals(current)){
                    price.removeTextChangedListener(this);

                    String cleanString = charSequence.toString().replaceAll("[$,.]", "");

                    double parsed = Double.parseDouble(cleanString);

                    String formatted = NumberFormat.getCurrencyInstance().format((parsed/100));

                    current = formatted;
                    price.setText(formatted);
                    price.setSelection(formatted.length());

                    price.addTextChangedListener(this);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    public void changeDateText (String date) {
        pickupDate.setTextColor(Color.BLACK);
        pickupDate.setTypeface(Typeface.DEFAULT);
        pickupDate.setText(date);
    }

    public void changeTimeText (String time) {
        pickupTime.setTextColor(Color.BLACK);
        pickupTime.setTypeface(Typeface.DEFAULT);
        pickupTime.setText(time);
    }

}
