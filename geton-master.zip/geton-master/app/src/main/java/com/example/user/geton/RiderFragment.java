package com.example.user.geton;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.example.user.geton.Dialog.DatePickerFragment;
import com.example.user.geton.Interfaces.RiderCommunicator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;

/**
 * Created by Yi Xuan on 6/2/2018.
 */

public class RiderFragment extends android.app.Fragment {

    // Views
    PlaceAutocompleteFragment locationPickup;
    PlaceAutocompleteFragment locationDestination;
    AutocompleteFilter countryFilter;
    View pickupCancel;
    View destinationCancel;
    String pickupURL, destinationURL;
    TextView pickupDate, pickupTime;

    // Communicator
    RiderCommunicator communicator;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Defines xml for fragment
        return inflater.inflate(R.layout.rider_upload_fragment, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Init cancel buttons for both input segment
        pickupCancel = view.findViewById(R.id.rider_clear_start);
        destinationCancel = view.findViewById(R.id.rider_clear_destination);

        // Init both PlaceAutocompleteFragment
        locationPickup = (PlaceAutocompleteFragment) getChildFragmentManager().findFragmentById(R.id.rider_start);
        locationDestination = (PlaceAutocompleteFragment) getChildFragmentManager().findFragmentById(R.id.rider_destination);

        // Changing attribute of search box (PlaceAutocompleteFragment)
        (locationPickup.getView().findViewById(R.id.place_autocomplete_search_button)).setVisibility(View.GONE);
        (locationDestination.getView().findViewById(R.id.place_autocomplete_search_button)).setVisibility(View.GONE);
        ((EditText)locationPickup.getView().findViewById(R.id.place_autocomplete_search_input)).setTextSize(17.0f);
        ((EditText)locationDestination.getView().findViewById(R.id.place_autocomplete_search_input)).setTextSize(17.0f);

        // Change hint for both PlaceAutocompleteFragment
        locationPickup.setHint("From...");
        locationDestination.setHint("To...");

        // Set filter for both PlaceAutoCompleteFragment
        countryFilter = new AutocompleteFilter.Builder()
                .setCountry("MY")
                .build();
        locationPickup.setFilter(countryFilter);
        locationDestination.setFilter(countryFilter);

        // init date picker and time picker
        pickupDate = view.findViewById(R.id.rider_datepicker);
        pickupTime = view.findViewById(R.id.rider_timepicker);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // Init communicator with activity
        communicator = (RiderCommunicator) getActivity();

        // Set onClickListener for both cancel button
        pickupCancel.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                // Empty the search box
                locationPickup.setText("");
                // Trigger listener in activity
                communicator.riderPickupCanceled();
                return true;
            }
        });
        destinationCancel.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                // Empty the search box
                locationDestination.setText("");
                // Trigger listener in activity
                communicator.riderDestinationCanceled();
                return true;
            }
        });

        // Set onClickListener for both PlaceAutoCompleteFragment
        locationPickup.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // Get place name in url format
                pickupURL = place.getAddress().toString();
                pickupURL = pickupURL.replace(" ","+"); // Replace space with '+' to meet url format
                // Send place URL to activity
                communicator.riderPickupSelected(pickupURL);
            }

            @Override
            public void onError(Status status) {
                // If failed, trigger fail listener in activity
                communicator.placeSelectedFailed("Error: "+status.getStatusMessage());
            }
        });
        locationDestination.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // Get place name in url format
                destinationURL = place.getAddress().toString();
                destinationURL = destinationURL.replace(" ","+"); // Replace space with '+' to meet url format
                // Send place URL to activity
                communicator.riderDestinationSelected(destinationURL);

            }

            @Override
            public void onError(Status status) {
                // If failed, trigger fail listener in activity
                communicator.placeSelectedFailed("Error: "+status.getStatusMessage());
            }
        });

        // Set onClickListener for date and time picker
        pickupDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                communicator.riderDateOnClicked();
            }
        });
        pickupTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                communicator.riderTimeOnClicked();
            }
        });

    }

    public void changeDateText (String date) {
        pickupDate.setTextColor(Color.BLACK);
        pickupDate.setTypeface(Typeface.DEFAULT);
        pickupDate.setText(date);

    }

    public void changeTimeText (String time) {
        pickupTime.setTextColor(Color.BLACK);
        pickupTime.setTypeface(Typeface.DEFAULT);
        pickupTime.setText(time);

    }


}
