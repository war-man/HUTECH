package com.example.user.geton;

import android.*;
import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.user.geton.Model.Vehicle;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;

public class VehicleActivity extends AppCompatActivity implements NumberPicker.OnValueChangeListener {

    // View
    Toolbar toolbar;
    ScrollView scrollView;
    EditText vehicleLicensePlate, vehicleModel, vehicleColor;
    LinearLayout vehicleSeatPicker, vehicleImagePicker;
    TextView vehicleSeats, vehicleImageName;
    ImageView vehicleImage;
    Button doneButton;

    // Firebase
    FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference users;
    DatabaseReference vehicleRef;
    FirebaseStorage storage;
    StorageReference vehiclePicRef;

    // Data string
    Uri uri; // image uri
    String licensePlateString, modelString, colorString, seatString;

    // Req code
    private static final int GALLERY_INTENT = 2;
    private static final int STORAGE_PERMISSION_REQUEST_CODE = 1016;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle);

        // set toolbar for activity
        toolbar = findViewById(R.id.vehicle_toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        // init view
        scrollView = findViewById(R.id.vehicle_scrollview);
        vehicleLicensePlate = findViewById(R.id.vehicle_licensePlate);
        vehicleModel = findViewById(R.id.vehicle_model);
        vehicleColor = findViewById(R.id.vehicle_color);
        vehicleSeatPicker = findViewById(R.id.vehicle_seatpicker);
        vehicleImagePicker = findViewById(R.id.vehicle_imagepicker);

        vehicleSeats = findViewById(R.id.vehicle_seats);
        vehicleImageName = findViewById(R.id.vehicle_imagename);
        vehicleImage = findViewById(R.id.vehicle_image);
        doneButton = findViewById(R.id.vehicle_submitButton);

        // set 'Done' button to not clickable
        doneButton.setAlpha(0.5f);
        doneButton.setClickable(false);

        // set onfocuslistener for all fields
        vehicleLicensePlate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    scrollView.post(new Runnable() {
                        @Override
                        public void run() {
                            scrollView.smoothScrollTo(0, vehicleLicensePlate.getTop()-30);
                        }
                    });
                }
            }
        });
        vehicleModel.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    scrollView.post(new Runnable() {
                        @Override
                        public void run() {
                            scrollView.smoothScrollTo(0, vehicleModel.getTop()-30);
                        }
                    });
                }
            }
        });
        vehicleColor.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    scrollView.post(new Runnable() {
                        @Override
                        public void run() {
                            scrollView.smoothScrollTo(0, vehicleColor.getTop()-30);
                        }
                    });
                }
            }
        });

        // set on click listener for seat picker & car image picker
        vehicleSeatPicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSeatPicker();
            }
        });
        vehicleImagePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(VehicleActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestStoragePermission();
                } else {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK);
                    galleryIntent.setType("image/*");
                    startActivityForResult(galleryIntent, GALLERY_INTENT);
                }
            }
        });

        // init firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        // db reference
        users = db.getReference("Users");
        vehicleRef = users.child(auth.getCurrentUser().getUid()).child("driver").child("vehicle");

        // init strings
        licensePlateString = "";
        modelString = "";
        colorString = "";
        seatString = "";

        // Add text watcher for all edittext
        vehicleLicensePlate.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String licensePlate = editable.toString();
                if (licensePlate.length() > 4) {
                    licensePlateString = licensePlate;
                    if (allFieldFilled()) {
                        doneButton.setAlpha(1);
                        doneButton.setClickable(true);
                    }
                } else {
                    doneButton.setAlpha(0.5f);
                    doneButton.setClickable(false);
                }
            }
        });
        vehicleModel.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String model = editable.toString();
                if (model.length() > 2) {
                    modelString = model;
                    if (allFieldFilled()) {
                        doneButton.setAlpha(1);
                        doneButton.setClickable(true);
                    }
                } else {
                    doneButton.setAlpha(0.5f);
                    doneButton.setClickable(false);
                }
            }
        });
        vehicleColor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String color = editable.toString();
                if (color.length() > 2) {
                    colorString = color;
                    if (allFieldFilled()) {
                        doneButton.setAlpha(1);
                        doneButton.setClickable(true);
                    }
                } else {
                    doneButton.setAlpha(0.5f);
                    doneButton.setClickable(false);
                }
            }
        });

        // listener for 'done' button
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allFieldFilled()) {
                    // Start progress dialog
                    final ProgressDialog mProgressDialog = new ProgressDialog(VehicleActivity.this);
                    mProgressDialog.setMessage("Adding vehicle ... ");
                    mProgressDialog.show();

                    // Build a vehicle object with user input
                    Vehicle vehicle = new Vehicle();
                    vehicle.setLicensePlate(licensePlateString);
                    vehicle.setModel(modelString);
                    vehicle.setColor(colorString);
                    vehicle.setSeats(seatString);

                    DatabaseReference currentVehicle = vehicleRef.child(licensePlateString);
                    currentVehicle.setValue(vehicle)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                // When vehicle details are successfully added to firebase database
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // Add vehicle image to firebase storage
                                    vehiclePicRef = storage.getReference("Users").child(auth.getCurrentUser().getUid()).child("vehiclePic").child(licensePlateString);
                                    vehiclePicRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        // When image successfully uploaded to storage
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            Toast.makeText(VehicleActivity.this,"Vehicle successfully added",Toast.LENGTH_SHORT).show();
                                            mProgressDialog.dismiss();
                                            finish();
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        // When image failed to upload to storage
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(VehicleActivity.this,"Error: "+e,Toast.LENGTH_LONG).show();
                                            mProgressDialog.dismiss();
                                        }
                                    });
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                // When vehicle details failed to upload to firebase database
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(VehicleActivity.this,"Error: "+e,Toast.LENGTH_LONG).show();
                                    mProgressDialog.dismiss();
                                }
                            });
                }
            }
        });

    }

    // onclick method for seat picker selection
    public void showSeatPicker () {

        final Dialog d = new Dialog(VehicleActivity.this);
        d.setTitle("Select number of seats");
        d.setContentView(R.layout.dialog_seatpicker);
        TextView confirm = d.findViewById(R.id.seatpicker_confirm);
        TextView cancel = d.findViewById(R.id.seatpicker_cancel);
        final NumberPicker np = d.findViewById(R.id.seatpicker);
        np.setMaxValue(8);
        np.setMinValue(1);
        np.setWrapSelectorWheel(false);
        np.setOnValueChangedListener(this);

        confirm.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                vehicleSeats.setText(String.valueOf(np.getValue()));
                seatString = String.valueOf(np.getValue());
                if (allFieldFilled()) {
                    doneButton.setAlpha(1);
                    doneButton.setClickable(true);
                }
                d.dismiss();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        d.getWindow().setLayout((5*width)/6,(3*height)/5);

        d.show();

    }

    // validate all input field
    public boolean allFieldFilled () {
        return (!TextUtils.isEmpty(licensePlateString) && !TextUtils.isEmpty(modelString) && !TextUtils.isEmpty(colorString) &&
                !TextUtils.isEmpty(seatString) && !Uri.EMPTY.equals(uri));
    }

    // Request to access photo gallery
    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this,new String[] {
                        android.Manifest.permission.READ_EXTERNAL_STORAGE},
                STORAGE_PERMISSION_REQUEST_CODE);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if ( v instanceof EditText) {
                Rect outRect = new Rect();
                v.getGlobalVisibleRect(outRect);
                if (!outRect.contains((int)event.getRawX(), (int)event.getRawY())) {
                    v.clearFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent( event );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case STORAGE_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                    {
                        Intent intent = new Intent(Intent.ACTION_PICK);
                        intent.setType("image/*");
                        startActivityForResult(intent, GALLERY_INTENT);
                    }
                }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_INTENT && resultCode == RESULT_OK) {
            uri = data.getData();

            // Load picked image into imageview with glide
            Glide.with(this)
                    .load(uri)
                    .into(vehicleImage);

            // Change text of button
            File f = new File(""+uri);
            String imageName = f.getName();
            vehicleImageName.setText(imageName);

        }
    }

    // number picker method
    @Override
    public void onValueChange(NumberPicker numberPicker, int i, int i1) {
        Log.i("yxgor",Integer.toString(i1));
    }

}
