package com.example.user.geton.Interfaces;

/**
 * Created by User on 8/2/2018.
 */

public interface DriverCommunicator {

    void driverPickupSelected (String pickupURL);

    void driverDestinationSelected (String destinationURL);

    void driverPickupCanceled ();

    void driverDestinationCanceled ();

    void driverPlaceSelectedFailed (String message);

    void driverDateOnClicked ();

    void driverTimeOnClicked ();

    void driverVehicleSelected ();

    void driverPriceSet ();

}
