package com.example.user.geton;

import android.*;
import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

import com.bumptech.glide.Glide;
import com.example.user.geton.HomemadeClass.Utility;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    // View
    RelativeLayout profilePicLayout;
    TextView profileUsername;
    CircleImageView profilePic,dialog_profilePic;
    Toolbar toolbar;
    LinearLayout addVehicleButton;
    LinearLayout vehicleList;

    // Firebase
    FirebaseAuth auth;
    DatabaseReference mDatabaseRef;
    DatabaseReference mUsername;
    DatabaseReference mVehicleRef;
    StorageReference mStorageRef;
    StorageReference mProfilePic;

    // Profile view
    String USER_NAME;
    Dialog profilePicDialog;
    ProgressDialog mProgressDialog;
    ProgressDialog loadingDialog;
    LayoutInflater inflater;

    String mCurrentPhotoPath;

    private static final int GALLERY_INTENT = 2;
    private static final int CAMERA_INTENT = 3;
    private static final int STORAGE_PERMISSION_REQUEST_CODE = 1016;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1017;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // start loading dialog until all init are finished
        loadingDialog = new ProgressDialog(this);
        loadingDialog.setMessage("Loading ...");
        loadingDialog.show();

        // set toolbar for activity
        toolbar = findViewById(R.id.profile_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        // init view
        profilePicLayout = findViewById(R.id.profilePic);
        profileUsername = findViewById(R.id.profile_username);
        profilePic = findViewById(R.id.profile_profilepic);
        addVehicleButton = findViewById(R.id.profile_addVehicle);
        vehicleList = findViewById(R.id.profile_vehicleList);
        inflater = LayoutInflater.from(this);

        // init firebase
        auth = FirebaseAuth.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("Users");
        mStorageRef = FirebaseStorage.getInstance().getReference("Users");
        mProfilePic = mStorageRef.child(auth.getCurrentUser().getUid()).child("profilePic");
        // vehicle database reference
        mVehicleRef = mDatabaseRef.child(auth.getCurrentUser().getUid()).child("driver").child("vehicle");

        // init dialog
        mProgressDialog = new ProgressDialog(this);
        profilePicDialog = new Dialog(this);

        // update user info
        updateUserProfile();
        updateUserPicture(profilePic);

        // update user vehicle list
        mVehicleRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //Get map of users in datasnapshot
                populateVehicleList((Map<String,Object>) dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        loadingDialog.dismiss();

        // add vehicle function
        addVehicleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start add vehicle activity
                startActivity(new Intent(ProfileActivity.this,VehicleActivity.class));
            }
        });

    }

    // Update user profile info
    private void updateUserProfile() {

        // Get user uid
        String uid = auth.getCurrentUser().getUid();

        // Update username of user
        mUsername = mDatabaseRef.child(uid).child("name");
        mUsername.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                USER_NAME = dataSnapshot.getValue(String.class);

                // Refresh profile username
                profileUsername.setText(USER_NAME);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    // Update user profile pic
    private void updateUserPicture(final CircleImageView image) {

        mProfilePic.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(ProfileActivity.this)
                        .load(uri)
                        .into(image);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Drawable avatar = getResources().getDrawable(R.drawable.avatar);
                image.setImageDrawable(avatar);
            }
        });


    }

    // Open profile picture dialog
    public void editProfilePic(View v) {
        Button cameraButton, galleryButton;
        ImageView cancelButton;

        // Set layout as view
        profilePicDialog.setContentView(R.layout.dialog_upload_profilepic);

        cameraButton = profilePicDialog.findViewById(R.id.profilepic_camera);
        galleryButton = profilePicDialog.findViewById(R.id.profilepic_gallery);
        cancelButton = profilePicDialog.findViewById(R.id.profilepic_cancel);
        dialog_profilePic = profilePicDialog.findViewById(R.id.profilepic_pic);

        // Display profile pic
        updateUserPicture(dialog_profilePic);

        // set camera button onclick listener
        cameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(ProfileActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestCameraPermission();
                } else {
                    dispatchTakePictureIntent();
                }
            }
        });
        // set gallery button onclick listener
        galleryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(ProfileActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestStoragePermission();
                } else {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK);
                    galleryIntent.setType("image/*");
                    startActivityForResult(galleryIntent, GALLERY_INTENT);
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                profilePicDialog.dismiss();
            }
        });

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        // display dialog at size of 5/6 of width of screen, 4/5 height of screen
        profilePicDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        profilePicDialog.getWindow().setLayout((5*width)/6,(4*height)/5);
        profilePicDialog.show();

    }

    // Request to access camera
    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this,new String[] {
                        Manifest.permission.CAMERA},
                CAMERA_PERMISSION_REQUEST_CODE);
    }

    // Request to access photo gallery
    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this,new String[] {
                        Manifest.permission.READ_EXTERNAL_STORAGE},
                        STORAGE_PERMISSION_REQUEST_CODE);
    }

    // Create temp file for image captured
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = "file:" + image.getAbsolutePath();
        return image;
    }

    // Start camera intent
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                Log.e("FileError",ex.getMessage());
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(ProfileActivity.this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, CAMERA_INTENT);
            }
        }
    }

    private void populateVehicleList(Map<String,Object> vehicles) {

        // clear all previous views inside linear layout
        vehicleList.removeAllViews();

        // init the list
        ArrayList<String> myVehicles = new ArrayList<>();

        // Set layout param for textview
        LayoutParams layoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
        layoutParams.gravity = Gravity.START;
        layoutParams.setMargins(30,35,15,35);

        //iterate through each vehicle, ignoring their license plate
        for (Map.Entry<String, Object> entry : vehicles.entrySet()){

            //Get vehicle map
            Map singleVehicle = (Map) entry.getValue();
            //Get phone field and append to list
            myVehicles.add((String) singleVehicle.get("licensePlate"));

        }

        // iterate through vehicle array list
        for (String vehicle : myVehicles) {
            TextView vehicleTextview = new TextView(this);

            int dividerHeight = (int) (getResources().getDisplayMetrics().density * 1);
            ImageView divider = new ImageView(this);
            LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            lp.height = dividerHeight;
            divider.setLayoutParams(lp);
            divider.setBackgroundColor(Color.GRAY);

            // Add textview text and text color programmically
            vehicleTextview.setLayoutParams(layoutParams);
            vehicleTextview.setText(vehicle);
            vehicleTextview.setTextColor(Color.BLACK);
            vehicleTextview.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            vehicleTextview.setClickable(true);
            // Add customized textview to linear layout
            vehicleList.addView(vehicleTextview);
            vehicleList.addView(divider);
        }

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_INTENT && resultCode == RESULT_OK) {
            // set progress dialog
            mProgressDialog.setMessage("Uploading ... ");
            mProgressDialog.show();

            Uri uri = data.getData();
            mProfilePic.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    mProgressDialog.dismiss();
                    updateUserPicture(profilePic);
                    Toast.makeText(ProfileActivity.this, "Successfully updated picture", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    mProgressDialog.dismiss();
                    Toast.makeText(ProfileActivity.this, "Error: " + e, Toast.LENGTH_LONG).show();
                }
            });

            profilePicDialog.dismiss();
        }

        if (requestCode == CAMERA_INTENT && resultCode == RESULT_OK) {
            // set progress dialog
            mProgressDialog.setMessage("Uploading ... ");
            mProgressDialog.show();

            Uri uri = Uri.parse(mCurrentPhotoPath);

            mProfilePic.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    mProgressDialog.dismiss();
                    updateUserPicture(profilePic);
                    Toast.makeText(ProfileActivity.this, "Successfully updated picture", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    mProgressDialog.dismiss();
                    Toast.makeText(ProfileActivity.this, "Error: " + e, Toast.LENGTH_LONG).show();
                }
            });

            profilePicDialog.dismiss();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case STORAGE_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                    {
                        Intent intent = new Intent(Intent.ACTION_PICK);
                        intent.setType("image/*");
                        startActivityForResult(intent, GALLERY_INTENT);
                    }
                }
            case CAMERA_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    {
                        dispatchTakePictureIntent();
                    }
                }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // update user vehicle list
        mVehicleRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //Get map of users in datasnapshot
                populateVehicleList((Map<String,Object>) dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}
