package com.example.user.geton.Common;

import com.example.user.geton.Remote.IGoogleAPI;
import com.example.user.geton.Remote.RetrofitClient;

/**
 * Created by User on 19/1/2018.
 */

public class Common {

    public static final String baseURL = "https://maps.googleapis.com";

    public static IGoogleAPI getGoogleAPI() {

        return RetrofitClient.getClient(baseURL).create(IGoogleAPI.class);

    }
}
