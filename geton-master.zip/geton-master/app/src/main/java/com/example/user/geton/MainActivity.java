package com.example.user.geton;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.FragmentManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.user.geton.Common.Common;
import com.example.user.geton.Dialog.DatePickerFragment;
import com.example.user.geton.Dialog.TimePickerFragment;
import com.example.user.geton.Interfaces.DriverCommunicator;
import com.example.user.geton.Interfaces.RiderCommunicator;
import com.example.user.geton.Remote.IGoogleAPI;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.SquareCap;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener,
        DatePickerDialog.OnDateSetListener,
        TimePickerDialog.OnTimeSetListener,
        RiderCommunicator,
        DriverCommunicator
{

    // Map
    private GoogleMap mMap;
    SupportMapFragment mapFragment;

    // Drawer view
    ActionBarDrawerToggle mDrawerToggle;
    DrawerLayout mDrawerLayout;
    NavigationView nav_view;
    Button button_continue;
    ImageButton button_drawer;
    // Profile view in drawer
    String USER_NAME;
    TextView drawer_username;
    CircleImageView profilePic;

    // request codes
    private static final int MY_PERMISSION_REQUEST_CODE = 1016;
    private static final int PLAY_SERVICE_REQUEST_CODE = 2401;

    // Location services and google APIs
    LocationRequest mLocationReq;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    IGoogleAPI mService;
    private List<LatLng> polylineList;
    private PolylineOptions polylineOptions;
    private Polyline greyPolyline;
    // Location update settings
    private static final int UPDATE_INTERVAL = 5000;
    private static final int FASTEST_INTERVAL = 3000;
    private static final int DISPLACEMENT = 10;

    // Firebase
    DatabaseReference mDatabaseRef;
    DatabaseReference mUsername;
    DatabaseReference mLocation;
    StorageReference mStorageRef;
    StorageReference mProfilePic;
    FirebaseAuth auth;
    GeoFire geoFire;

    // Radio switcher view
    RadioButton RIDER_MODE, DRIVER_MODE;
    FragmentManager manager;

    // rider fragment items
    RiderFragment riderFragment;
    String rider_pickup, rider_destination;
    String rider_date, rider_time;

    // driver fragment items
    DriverFragment driverFragment;
    String driver_pickup, driver_destination;
    String driver_date, driver_time;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect to GoogleApiClient
        buildGoogleApiClient();
        // Create location request
        createLocationRequest();

        // init radio button & rider fragment
        RIDER_MODE = findViewById(R.id.rider_mode);
        DRIVER_MODE = findViewById(R.id.driver_mode);
        manager = getFragmentManager();
        riderFragment = new RiderFragment();
        driverFragment = new DriverFragment();
        android.app.FragmentTransaction transaction = manager.beginTransaction();
        transaction.add(R.id.main_placeholder,riderFragment,"RIDER");
        transaction.commit();

        // Set hamburger icon to open drawer
        button_drawer = findViewById(R.id.main_drawer_button);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        button_drawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDrawerLayout.openDrawer(Gravity.START);
            }
        });

        // Obtain the map fragment and notified when map is ready to use
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.main_map);
        mapFragment.getMapAsync(this);

        // Init view
        button_continue = findViewById(R.id.main_continue_button);

        // Init database and storage
        auth = FirebaseAuth.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("Users");
        mStorageRef = FirebaseStorage.getInstance().getReference("Users");
        mProfilePic = mStorageRef.child(auth.getCurrentUser().getUid()).child("profilePic");

        // Update user profile info
        nav_view = findViewById(R.id.navigation_view);
        View headerView = nav_view.getHeaderView(0);
        drawer_username = headerView.findViewById(R.id.drawer_username);
        updateUserProfile();

        // Set onClick event for profile pic
        profilePic = headerView.findViewById(R.id.drawer_profilepic);
        updateUserPicture(profilePic);
        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Close drawer
                mDrawerLayout.closeDrawer(Gravity.START);
                // Move user to profile page
                startActivity(new Intent(MainActivity.this,ProfileActivity.class));
            }
        });

        // Init rider trip details strings
        rider_pickup = "";
        rider_destination = "";
        rider_date = "";
        rider_time = "";
        // Init driver upload details strings
        driver_pickup = "";
        driver_destination = "";
        driver_date = "";
        driver_time = "";

        // Init GeoFire
        mLocation = mDatabaseRef.child(auth.getCurrentUser().getUid()).child("location");
        geoFire = new GeoFire(mLocation);

        polylineList = new ArrayList<>();
        mService = Common.getGoogleAPI();

    }

    @Override
    protected void onResume() {
        super.onResume();

        updateUserPicture(profilePic);
    }

    // Fetch JSON data from Directions API and display on map
    private void getDirection(String pickup, String destination) {

        // clear map
        mMap.clear();

        String requestAPI = null;

        try {

            requestAPI = "https://maps.googleapis.com/maps/api/directions/json?"+
                    "mode=driving&"+
                    "transit_routing_preference=less_driving&"+
                    "origin="+pickup+"&"+
                    "destination="+destination+"&"+
                    "key="+getResources().getString(R.string.google_direction_api);

            Log.d("requestAPI",requestAPI); // print URL for debugging purpose
            mService.getPath(requestAPI)
                    .enqueue(new Callback<String>() {
                        @Override
                        public void onResponse(Call<String> call, Response<String> response) {
                            try {

                                // Fetch json object
                                JSONObject jsonObject = new JSONObject(response.body().toString());
                                JSONArray jsonArray = jsonObject.getJSONArray("routes");

                                for (int i=0;i<jsonArray.length();i++) {
                                    JSONObject route = jsonArray.getJSONObject(i);
                                    JSONObject poly = route.getJSONObject("overview_polyline");
                                    String polyline = poly.getString("points");
                                    polylineList = decodePoly(polyline);
                                }
                                // Adjusting bounds
                                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                                for (LatLng latLng:polylineList) {
                                    builder.include(latLng);
                                }
                                LatLngBounds bounds = builder.build();
                                CameraUpdate mCameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds,0);
                                mMap.animateCamera(mCameraUpdate);

                                // Edit polyline options
                                polylineOptions = new PolylineOptions();
                                polylineOptions.color(Color.BLACK);
                                polylineOptions.width(10);
                                polylineOptions.startCap(new SquareCap());
                                polylineOptions.endCap(new SquareCap());
                                polylineOptions.jointType(JointType.ROUND);
                                polylineOptions.addAll(polylineList);
                                greyPolyline = mMap.addPolyline(polylineOptions);

                                // Add marker for pickup location
                                mMap.addMarker(new MarkerOptions()
                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.pickup_marker))
                                        .position(polylineList.get(0))
                                        .title("Pickup"));

                                // Add marker for destination
                                mMap.addMarker(new MarkerOptions()
                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.destination_marker))
                                        .position(polylineList.get(polylineList.size()-1))
                                        .title("Destination"));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(Call<String> call, Throwable t) {
                            Toast.makeText(MainActivity.this,""+t.getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // Start tracking user location
    private void setUpLocation() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)  {
            requestLocationPermission();
        } else {
            if (checkPlayServices()) {
                startLocationUpdates();
                displayLocation();
            }
        }

    }

    // Display latest user location and center screen to it
    private void displayLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestLocationPermission();
        } else {
            mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
            if (mLastLocation != null) {

                // Lat n Lng of current location
                double currentLat = mLastLocation.getLatitude();
                double currentLng = mLastLocation.getLongitude();

                // Convert into LatLng object
                final LatLng currentPos = new LatLng(currentLat,currentLng);

                // Make update to database for latest location
                geoFire.setLocation("lastLocation", new GeoLocation(currentLat, currentLng), new GeoFire.CompletionListener() {
                    @Override
                    public void onComplete(String key, DatabaseError error) {
                        // Move camera to user position
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentPos,15.0f));
                    }
                });
            }
        }
    }

    // Start updating user's location to screen
    private void startLocationUpdates() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            requestLocationPermission();

        } else {

            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,mLocationReq,this);

        }
    }

    // Stop updating user's location to screen
    private void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient,this);
    }

    // Prompt user to access their phone location services
    private void requestLocationPermission() {

        ActivityCompat.requestPermissions(this,new String[] {
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION},
                MY_PERMISSION_REQUEST_CODE);

    }

    // Build and connect to GoogleApiClient
    private void buildGoogleApiClient() {

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        // Connect to service
        mGoogleApiClient.connect();

    }

    // Init location request
    private void createLocationRequest() {

        mLocationReq = new LocationRequest();
        mLocationReq.setInterval(UPDATE_INTERVAL);
        mLocationReq.setFastestInterval(FASTEST_INTERVAL);
        mLocationReq.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationReq.setSmallestDisplacement(DISPLACEMENT);

    }

    // Check validation of play services of user's phone
    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode,this,PLAY_SERVICE_REQUEST_CODE).show();
            } else {
                Toast.makeText(this,"THIS DEVICE IS NOT SUPPORTED",Toast.LENGTH_SHORT).show();
            }
            return false;
        }
        return true;
    }

    // Update user profile info
    private void updateUserProfile() {

        // Get user uid
        String uid = auth.getCurrentUser().getUid();

        // Update username of user
        mUsername = mDatabaseRef.child(uid).child("name");
        mUsername.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                USER_NAME = dataSnapshot.getValue(String.class);

                // Refresh profile username
                drawer_username.setText(USER_NAME);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    // Update user profile pic
    private void updateUserPicture(final CircleImageView image) {

        mProfilePic.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(MainActivity.this)
                        .load(uri)
                        .into(profilePic);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Drawable avatar = getResources().getDrawable(R.drawable.avatar);
                image.setImageDrawable(avatar);
            }
        });


    }

    // Decoding the polypath
    private List decodePoly(String encoded) {

        List poly = new ArrayList();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }

        return poly;
    }

    // User current state change handler
    public void onRadioButtonClicked(View view) {

        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.rider_mode:
                if (checked) {
                    // Switch to rider fragment with custom animation
                    android.app.FragmentTransaction transaction = manager.beginTransaction();
                    transaction.setCustomAnimations(R.animator.slide_in_left, R.animator.slide_in_left);
                    transaction.replace(R.id.main_placeholder,riderFragment,"RIDER");
                    transaction.commit();
                    // Clear markers on map
                    mMap.clear();
                    // Set 'continue' button not clickable
                    button_continue.setAlpha(0.5f);
                    button_continue.setClickable(false);
                    // Clear all driver trip detail strings
                    driver_pickup = "";
                    driver_destination = "";
                    driver_date = "";
                    driver_time = "";
                }
                break;
            case R.id.driver_mode:
                if (checked) {
                    // Switch to driver fragment with custom animation
                    android.app.FragmentTransaction transaction = manager.beginTransaction();
                    transaction.setCustomAnimations(R.animator.slide_in_right, R.animator.slide_in_right);
                    transaction.replace(R.id.main_placeholder,driverFragment,"DRIVER");
                    transaction.commit();
                    // Clear markers on map
                    mMap.clear();
                    // Set 'continue' button not clickable
                    button_continue.setAlpha(0.5f);
                    button_continue.setClickable(false);
                    // Clear all rider trip detail strings
                    rider_pickup = "";
                    rider_destination = "";
                    rider_date = "";
                    rider_time = "";
                }
                break;
        }
    }

    // Check if both rider PlaceAutoCompleteFragment are filled
    public boolean riderPlaceFilled() {
        return (!TextUtils.isEmpty(rider_pickup) && !TextUtils.isEmpty(rider_destination));
    }
    // Check if all rider details are filled
    public boolean allRiderFieldFilled() {

        return (!TextUtils.isEmpty(rider_pickup) && !TextUtils.isEmpty(rider_destination) && !TextUtils.isEmpty(rider_date)
                && !TextUtils.isEmpty(rider_time));

    }

    // Check if both rider PlaceAutoCompleteFragment are filled
    public boolean driverPlaceFilled() {
        return (!TextUtils.isEmpty(driver_pickup) && !TextUtils.isEmpty(driver_destination));
    }
    // Check if all rider details are filled
    public boolean allDriverFieldFilled() {

        return (!TextUtils.isEmpty(driver_pickup) && !TextUtils.isEmpty(driver_destination) && !TextUtils.isEmpty(driver_date)
                && !TextUtils.isEmpty(driver_time));

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case MY_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    {
                        if (checkPlayServices()) {
                            startLocationUpdates();
                            displayLocation();
                        }
                    }
                }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        // Change map style to customized may style
        try {
            boolean isSuccess = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(this,R.raw.geton_map_style)
            );
            if (!isSuccess) {
                Log.e("MAP_STYLE_ERROR","Map style load failed");
            }
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }

        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.setTrafficEnabled(false);
        mMap.setIndoorEnabled(false);
        mMap.setBuildingsEnabled(false);
        mMap.getUiSettings().setZoomControlsEnabled(true);

        mMap.setPadding(40,800,40,200);

    }

    @Override
    public void onLocationChanged(Location location) {

        mLastLocation = location;

        // Lat n Lng of current location
        double currentLat = mLastLocation.getLatitude();
        double currentLng = mLastLocation.getLongitude();

        // Convert into LatLng object
        final LatLng currentPos = new LatLng(currentLat,currentLng);

        // Make update to database for latest location
        geoFire.setLocation("lastLocation", new GeoLocation(currentLat, currentLng), new GeoFire.CompletionListener() {
            @Override
            public void onComplete(String key, DatabaseError error) {
                // Move camera to user position
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentPos,15.0f));
            }
        });

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (mGoogleApiClient.isConnected()) {
            setUpLocation();
        } else {
            Toast.makeText(this,"GoogleApiClient disconnected",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if ( v instanceof EditText) {
                Rect outRect = new Rect();
                v.getGlobalVisibleRect(outRect);
                if (!outRect.contains((int)event.getRawX(), (int)event.getRawY())) {
                    v.clearFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent( event );
    }

    // Date dialog listener
    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        Calendar datePicked = Calendar.getInstance();
        datePicked.set(Calendar.YEAR,i);
        datePicked.set(Calendar.MONTH,i1);
        datePicked.set(Calendar.DAY_OF_MONTH,i2);

        android.support.v4.app.FragmentManager fragManager = getSupportFragmentManager();

        // When triggered by rider fragment
        if (fragManager.findFragmentByTag("rider_date") != null) {
            String date = DateFormat.getDateInstance().format(datePicked.getTime());
            // Change rider fragment date textview
            riderFragment.changeDateText(date);
            rider_date = datePicked.toString();
            // Check if all field are filled
            if (allRiderFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }

        // When triggered by driver fragment
        if (fragManager.findFragmentByTag("driver_date") != null) {
            String date = DateFormat.getDateInstance().format(datePicked.getTime());
            // Change rider fragment date textview
            driverFragment.changeDateText(date);
            driver_date = datePicked.toString();
            // Check if all field are filled
            if (allDriverFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }
    }

    // Time dialog listener
    @Override
    public void onTimeSet(TimePicker timePicker, int i, int i1) {
        String hour, minute;
        // modify hour format
        if (i<10) {
            hour = "0"+Integer.toString(i);
        } else {
            hour = Integer.toString(i);
        }
        // modify minute format
        if (i1<10) {
            minute = "0"+Integer.toString(i1);
        } else {
            minute = Integer.toString(i1);
        }

        android.support.v4.app.FragmentManager fragManager = getSupportFragmentManager();

        if (fragManager.findFragmentByTag("rider_time") != null) {
            String time = hour+":"+minute;
            // Change rider fragment time textview
            riderFragment.changeTimeText(time);
            rider_time = hour+minute;
            // Check if all field are filled
            if (allRiderFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }

        if (fragManager.findFragmentByTag("driver_time") != null) {
            String time = hour+":"+minute;
            // Change rider fragment time textview
            driverFragment.changeTimeText(time);
            driver_time = hour+minute;
            // Check if all field are filled
            if (allDriverFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }

    }

    // Interface of rider communicator
    @Override
    public void riderPickupSelected(String pickupURL) {
        rider_pickup = pickupURL;
        if (riderPlaceFilled()) {
            // Draw direction to map
            getDirection(rider_pickup, rider_destination);

            // Stop location updates
            stopLocationUpdates();

            // Check if all field are filled
            if (allRiderFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }
    }

    @Override
    public void riderDestinationSelected(String destinationURL) {
        rider_destination = destinationURL;
        if (riderPlaceFilled()) {
            // Draw direction to map
            getDirection(rider_pickup, rider_destination);

            // Stop location updates
            stopLocationUpdates();

            // Check if all field are filled
            if (allRiderFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }
    }

    @Override
    public void riderPickupCanceled() {
        rider_pickup = "";
        button_continue.setAlpha(0.5f);
        button_continue.setClickable(false);
    }

    @Override
    public void riderDestinationCanceled() {
        rider_destination = "";
        button_continue.setAlpha(0.5f);
        button_continue.setClickable(false);
    }

    @Override
    public void placeSelectedFailed(String message) {
        // Display error message
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();
    }

    @Override
    public void riderDateOnClicked() {
        android.support.v4.app.DialogFragment datePicker = new DatePickerFragment();
        datePicker.show(getSupportFragmentManager(),"rider_date");
    }

    @Override
    public void riderTimeOnClicked() {
        android.support.v4.app.DialogFragment timePicker = new TimePickerFragment();
        timePicker.show(getSupportFragmentManager(),"rider_time");
    }

    // Interface of driver communicator
    @Override
    public void driverPickupSelected(String pickupURL) {
        driver_pickup = pickupURL;
        if (driverPlaceFilled()) {
            // Draw direction to map
            getDirection(driver_pickup, driver_destination);

            // Stop location updates
            stopLocationUpdates();

            // Check if all field are filled
            if (allDriverFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }
    }

    @Override
    public void driverDestinationSelected(String destinationURL) {
        driver_destination = destinationURL;
        if (driverPlaceFilled()) {
            // Draw direction to map
            getDirection(driver_pickup, driver_destination);

            // Stop location updates
            stopLocationUpdates();

            // Check if all field are filled
            if (allDriverFieldFilled()) {
                // Set 'Continue' button clickable
                button_continue.setAlpha(1);
                button_continue.setClickable(true);
            }
        }
    }

    @Override
    public void driverPickupCanceled() {
        driver_pickup = "";
        button_continue.setAlpha(0.5f);
        button_continue.setClickable(false);
    }

    @Override
    public void driverDestinationCanceled() {
        driver_destination = "";
        button_continue.setAlpha(0.5f);
        button_continue.setClickable(false);
    }

    @Override
    public void driverPlaceSelectedFailed(String message) {
        // Display error message
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();
    }

    @Override
    public void driverDateOnClicked() {
        android.support.v4.app.DialogFragment datePicker = new DatePickerFragment();
        datePicker.show(getSupportFragmentManager(),"driver_date");
    }

    @Override
    public void driverTimeOnClicked() {
        android.support.v4.app.DialogFragment timePicker = new TimePickerFragment();
        timePicker.show(getSupportFragmentManager(),"driver_time");
    }

    @Override
    public void driverVehicleSelected() {

    }

    @Override
    public void driverPriceSet() {

    }

}
