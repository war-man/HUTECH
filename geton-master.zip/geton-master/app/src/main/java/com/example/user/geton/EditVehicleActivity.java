package com.example.user.geton;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class EditVehicleActivity extends AppCompatActivity {

    // views
    Toolbar toolbar;
    EditText vehicleLicensePlate, vehicleModel, vehicleColor;
    LinearLayout vehicleSeatPicker, vehicleImagePicker;
    TextView vehicleSeats, vehicleImageName;
    ImageView vehicleImage;
    Button doneButton;

    // Firebase
    FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference users;
    DatabaseReference vehicleRef;
    FirebaseStorage storage;
    StorageReference vehiclePicRef;

    // Car details string
    String licensePlateString, modelString, colorString, seatString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_vehicle);

        // set toolbar for activity
        toolbar = findViewById(R.id.vehicle_toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        // init strings
        licensePlateString = "";
        modelString = "";
        colorString = "";
        seatString = "";

        // init view
        vehicleLicensePlate = findViewById(R.id.edit_licensePlate);
        vehicleModel = findViewById(R.id.edit_model);
        vehicleColor = findViewById(R.id.edit_color);
        vehicleSeatPicker = findViewById(R.id.edit_seatpicker);
        vehicleImagePicker = findViewById(R.id.edit_imagepicker);
        vehicleSeats = findViewById(R.id.edit_seats);
        vehicleImage = findViewById(R.id.edit_image);
        vehicleImageName = findViewById(R.id.edit_imagename);

        // init firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        // set firebase ref
        users = db.getReference("Users");
        vehicleRef = users.child(auth.getCurrentUser().getUid()).child("driver").child("vehicle");
        vehiclePicRef = storage.getReference("Users").child(auth.getCurrentUser().getUid()).child("vehiclePic").child(licensePlateString);

    }

    private void getVehicleDetails() {

    }

}
