package com.example.user.geton.Interfaces;

/**
 * Created by Yi Xuan on 8/2/2018.
 */

public interface RiderCommunicator {

    void riderPickupSelected (String pickupURL);

    void riderDestinationSelected (String destinationURL);

    void riderPickupCanceled ();

    void riderDestinationCanceled ();

    void placeSelectedFailed (String message);

    void riderDateOnClicked ();

    void riderTimeOnClicked ();

}
