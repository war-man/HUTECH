package com.example.user.geton;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.user.geton.Model.User;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    /* UI Widgets */
    private Button btnSignup, btnLogin;
    private EditText inputEmail, inputPassword;
    private ConstraintLayout root_layout;

    FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Init View
        btnSignup = findViewById(R.id.login_button_signup);
        btnLogin = findViewById(R.id.login_button_login);
        root_layout = findViewById(R.id.root_layout);
        inputEmail = findViewById(R.id.login_userEmail);
        inputPassword = findViewById(R.id.login_userPassword);

        // Init firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        users = db.getReference("Users");

        // Set event listener for signup button
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showRegisterDialog();
            }
        });
        // Set event listener for login button
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userLogin();
            }
        });

    }

    /**
     * This method shows a sign up page for new user.
     *
     * @author Yi Xuan
     */
    private void showRegisterDialog() {
        // Setup user register dialog
        AlertDialog.Builder register_dialog = new AlertDialog.Builder(this);
        register_dialog.setTitle("REGISTER");
        register_dialog.setMessage("Fill you information in text field.");

        LayoutInflater inflater = LayoutInflater.from(this);
        View layout_register = inflater.inflate(R.layout.layout_register,null);

        // Set view as layout_register
        register_dialog.setView(layout_register);

        // Init user input
        final TextInputEditText user_name = layout_register.findViewById(R.id.register_name);
        final TextInputEditText user_email = layout_register.findViewById(R.id.register_email);
        final TextInputEditText user_password = layout_register.findViewById(R.id.register_password);

        // Set positive button
        register_dialog.setPositiveButton("REGISTER", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                // Remove dialog from screen
                dialogInterface.dismiss();

                // Check validation
                if (TextUtils.isEmpty(user_name.getText().toString()))
                {
                    Snackbar.make(root_layout,"Please enter your name",Snackbar.LENGTH_SHORT)
                            .show();
                    return;
                }
                if (TextUtils.isEmpty(user_email.getText().toString()))
                {
                    Snackbar.make(root_layout,"Please enter e-mail address",Snackbar.LENGTH_SHORT)
                            .show();
                    return;
                }
                if (TextUtils.isEmpty(user_password.getText().toString()))
                {
                    Snackbar.make(root_layout,"Please enter password",Snackbar.LENGTH_SHORT)
                            .show();
                    return;
                }
                if (user_password.getText().toString().length() < 6)
                {
                    Snackbar.make(root_layout,"Password is too short!",Snackbar.LENGTH_SHORT)
                            .show();
                    return;
                }

                // Register new user
                auth.createUserWithEmailAndPassword(user_email.getText().toString(),user_password.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                // Save driver data to db
                                User user = new User();
                                user.setName(user_name.getText().toString());
                                user.setEmail(user_email.getText().toString());
                                user.setPassword(user_password.getText().toString());

                                // Use email as key
                                users.child(auth.getCurrentUser().getUid())
                                        .setValue(user)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {

                                            // Listener for successful registration
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                // Pop out snackbar to alert user that signup is successful
                                                Snackbar.make(root_layout,"Successfully registered!",Snackbar.LENGTH_SHORT)
                                                        .show();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                // Pop out snackbar to alert user that signup is unsuccessful
                                                Snackbar.make(root_layout,"Error: "+e.getMessage(),Snackbar.LENGTH_SHORT)
                                                        .show();
                                            }
                                        });

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Pop out snackbar to alert user that signup is unsuccessful
                                Snackbar.make(root_layout,"Error: "+e.getMessage(),Snackbar.LENGTH_SHORT)
                                        .show();
                            }
                        });
            }
        });

        // Set negative button
        register_dialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Close dialog
                dialogInterface.dismiss();

            }
        });

        // Display dialog
        register_dialog.show();
    }

    /**
     * This method checks if email and password entered are correct, if both are valid then
     * log user into main page of app
     *
     * @author Yi Xuan
     */
    private void userLogin() {

        // check e-mail and password input
        if (TextUtils.isEmpty(inputEmail.getText().toString())) {
            Snackbar.make(root_layout,"Please enter e-mail",Snackbar.LENGTH_SHORT)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(inputPassword.getText().toString())) {
            Snackbar.make(root_layout,"Please enter password",Snackbar.LENGTH_SHORT)
                    .show();
            return;
        }

        // If login success, move user to main page, else return error message
        auth.signInWithEmailAndPassword(inputEmail.getText().toString(),inputPassword.getText().toString())
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        // Set user's sharedpreferences to logged-in state, so user don't need to login everytime the app launches
                        SharedPreferences user_preferences = LoginActivity.this.getSharedPreferences("com.example.user.geton", Context.MODE_PRIVATE);
                        try {
                            user_preferences.edit().putBoolean("USER_LOGGED",true).apply();
                            user_preferences.edit().putString("USER_EMAIL",inputEmail.getText().toString()).apply();
                            user_preferences.edit().putString("USER_PASS",inputPassword.getText().toString()).apply();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        startActivity(new Intent(LoginActivity.this,MainActivity.class));
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Snackbar.make(root_layout,"Error login: "+e.getMessage(),Snackbar.LENGTH_SHORT)
                                .show();
                    }
                });

    }

}
