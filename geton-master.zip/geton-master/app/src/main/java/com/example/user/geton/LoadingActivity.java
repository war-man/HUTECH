package com.example.user.geton;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoadingActivity extends AppCompatActivity {

    TextView loading_logo, loading_title;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);

        // Init view
        loading_logo = findViewById(R.id.loading_logo);
        loading_title = findViewById(R.id.loading_title);
        auth = FirebaseAuth.getInstance();

        // Animation
        Animation splash_anim = AnimationUtils.loadAnimation(this,R.anim.splash_transition);
        loading_logo.setAnimation(splash_anim);
        loading_title.setAnimation(splash_anim);

        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(2000);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {

                    // Check if user had previously logged in
                    SharedPreferences user_preferences = LoadingActivity.this.getSharedPreferences("com.example.user.geton", Context.MODE_PRIVATE);

                    // If yes, log user into main activity, else prompt user to login
                    if (user_preferences.getBoolean("USER_LOGGED", false)) {

                        // Retrieve user e-mail & password
                        String user_email = user_preferences.getString("USER_EMAIL","");
                        String user_pass = user_preferences.getString("USER_PASS","");

                        // If login success, move user to main page, else return error message
                        auth.signInWithEmailAndPassword(user_email,user_pass)
                                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                    @Override
                                    public void onSuccess(AuthResult authResult) {
                                        startActivity(new Intent(LoadingActivity.this,MainActivity.class));
                                        finish();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        startActivity(new Intent(LoadingActivity.this,LoginActivity.class));
                                        finish();
                                    }
                                });

                    } else {

                        startActivity(new Intent(LoadingActivity.this,LoginActivity.class));
                        finish();

                    }
                }
            }
        };
        timer.start();
    }
}
