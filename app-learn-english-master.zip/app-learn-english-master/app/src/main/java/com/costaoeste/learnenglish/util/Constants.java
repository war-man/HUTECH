package com.costaoeste.learnenglish.util;

/**
 * Created by pablo on 30/4/17.
 */

public class Constants {

    public static final String BUNDLE_PARCELABLE = "BUNDLE_PARCELABLE";

}
