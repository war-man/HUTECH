package com.costaoeste.learnenglish.ui.base;

public interface MvpView {

}