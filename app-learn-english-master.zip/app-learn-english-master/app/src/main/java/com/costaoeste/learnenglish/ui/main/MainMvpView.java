package com.costaoeste.learnenglish.ui.main;

import com.costaoeste.learnenglish.ui.base.MvpView;

public interface MainMvpView extends MvpView {

    void saveVocabulary();

}