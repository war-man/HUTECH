package com.costaoeste.learnenglish.data.model;

public class VocabularyRemoteResultsSensesGramatical_info implements java.io.Serializable {
    private static final long serialVersionUID = 1749369008018853782L;
    private String type;

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
