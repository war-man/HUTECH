package com.example.cpd.ehutech.model.Login;

public class ThongtinSinhvien {
    public String getMssv() {
        return mssv;
    }

    public void setMssv(String mssv) {
        this.mssv = mssv;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public String getKhoa() {
        return khoa;
    }

    public void setKhoa(String khoa) {
        this.khoa = khoa;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getChuky() {
        return chuky;
    }

    public void setChuky(String chuky) {
        this.chuky = chuky;
    }

    String mssv;
    String ten;
    String lop;
    String khoa;
    String token;
    String chuky;

}
